package gnu.io;

public interface CommDriver {
  CommPort getCommPort(String paramString, int paramInt);
  
  void initialize();
}


/* Location:              C:\diao\bin\diao.jar!\lib\RXTXcomm.jar!\gnu\io\CommDriver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */