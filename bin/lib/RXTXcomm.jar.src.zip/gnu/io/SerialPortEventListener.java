package gnu.io;

import java.util.EventListener;

public interface SerialPortEventListener extends EventListener {
  void serialEvent(SerialPortEvent paramSerialPortEvent);
}


/* Location:              C:\diao\bin\diao.jar!\lib\RXTXcomm.jar!\gnu\io\SerialPortEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */