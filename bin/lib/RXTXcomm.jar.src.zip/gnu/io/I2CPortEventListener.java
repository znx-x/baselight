package gnu.io;

import java.util.EventListener;

public interface I2CPortEventListener extends EventListener {
  void I2CEvent(I2CPortEvent paramI2CPortEvent);
}


/* Location:              C:\diao\bin\diao.jar!\lib\RXTXcomm.jar!\gnu\io\I2CPortEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */