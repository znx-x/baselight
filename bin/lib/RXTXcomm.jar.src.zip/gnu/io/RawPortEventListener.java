package gnu.io;

import java.util.EventListener;

public interface RawPortEventListener extends EventListener {
  void RawEvent(RawPortEvent paramRawPortEvent);
}


/* Location:              C:\diao\bin\diao.jar!\lib\RXTXcomm.jar!\gnu\io\RawPortEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */