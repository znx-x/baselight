package gnu.io;

import java.util.EventListener;

public interface ParallelPortEventListener extends EventListener {
  void parallelEvent(ParallelPortEvent paramParallelPortEvent);
}


/* Location:              C:\diao\bin\diao.jar!\lib\RXTXcomm.jar!\gnu\io\ParallelPortEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */