package gnu.io;

import java.util.EventListener;

public interface RS485PortEventListener extends EventListener {
  void RS485Event(RS485PortEvent paramRS485PortEvent);
}


/* Location:              C:\diao\bin\diao.jar!\lib\RXTXcomm.jar!\gnu\io\RS485PortEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */